#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"
DERIVED_DATA="${BUILD_DIR}/DerivedData"
IPA_DIR="${BUILD_DIR}/ipa"
APP_PATH="${DERIVED_DATA}/Build/Products/Release-iphoneos/CBrainIOS.app"
IPA_PATH="${IPA_DIR}/CBrainIOS.ipa"
TIPA_PATH="${IPA_DIR}/CBrainIOS.tipa"

rm -rf "${BUILD_DIR}"
mkdir -p "${IPA_DIR}"

xcodebuild \
  -project "${ROOT_DIR}/CBrainIOS.xcodeproj" \
  -scheme CBrainIOS \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "${DERIVED_DATA}" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  clean build

if [[ ! -d "${APP_PATH}" ]]; then
  echo "App bundle not found: ${APP_PATH}" >&2
  exit 1
fi

if [[ ! -f "${APP_PATH}/Info.plist" ]]; then
  echo "Info.plist not found in app bundle: ${APP_PATH}/Info.plist" >&2
  exit 1
fi

/usr/bin/plutil -lint "${APP_PATH}/Info.plist"
BUNDLE_ID="$(/usr/libexec/PlistBuddy -c "Print CFBundleIdentifier" "${APP_PATH}/Info.plist")"
APP_EXECUTABLE="$(/usr/libexec/PlistBuddy -c "Print CFBundleExecutable" "${APP_PATH}/Info.plist")"

if [[ -z "${BUNDLE_ID}" || -z "${APP_EXECUTABLE}" ]]; then
  echo "Bundle identifier or executable is missing from Info.plist" >&2
  exit 1
fi

if [[ ! -f "${APP_PATH}/${APP_EXECUTABLE}" ]]; then
  echo "Executable not found in app bundle: ${APP_PATH}/${APP_EXECUTABLE}" >&2
  exit 1
fi

chmod +x "${APP_PATH}/${APP_EXECUTABLE}"
/usr/bin/xattr -cr "${APP_PATH}" 2>/dev/null || true

/usr/bin/codesign \
  --force \
  --deep \
  --sign - \
  --timestamp=none \
  --generate-entitlement-der \
  "${APP_PATH}"

/usr/bin/codesign --verify --deep --verbose=2 "${APP_PATH}"
if [[ ! -f "${APP_PATH}/_CodeSignature/CodeResources" ]]; then
  echo "Code signature resources were not generated." >&2
  exit 1
fi

WORK_DIR="${BUILD_DIR}/PayloadWork"
mkdir -p "${WORK_DIR}/Payload"
cp -R "${APP_PATH}" "${WORK_DIR}/Payload/"

(
  cd "${WORK_DIR}"
  /usr/bin/zip -qry -y "${IPA_PATH}" Payload
)

cp "${IPA_PATH}" "${TIPA_PATH}"

for package in "${IPA_PATH}" "${TIPA_PATH}"; do
  /usr/bin/unzip -tq "${package}" "Payload/CBrainIOS.app/Info.plist" >/dev/null
  /usr/bin/unzip -tq "${package}" "Payload/CBrainIOS.app/${APP_EXECUTABLE}" >/dev/null
  /usr/bin/unzip -tq "${package}" "Payload/CBrainIOS.app/_CodeSignature/CodeResources" >/dev/null
done

echo "Bundle identifier: ${BUNDLE_ID}"
echo "Bundle executable: ${APP_EXECUTABLE}"
echo "Code signature:"
/usr/bin/codesign -dv "${APP_PATH}" 2>&1 | /usr/bin/head -80
echo "IPA contents:"
/usr/bin/zipinfo -1 "${IPA_PATH}" | /usr/bin/head -80
echo "${IPA_PATH}"
echo "${TIPA_PATH}"
