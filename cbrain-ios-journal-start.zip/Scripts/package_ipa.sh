#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"
DERIVED_DATA="${BUILD_DIR}/DerivedData"
IPA_DIR="${BUILD_DIR}/ipa"
APP_PATH="${DERIVED_DATA}/Build/Products/Release-iphoneos/CBrainIOS.app"
IPA_PATH="${IPA_DIR}/CBrainIOS.ipa"
TIPA_PATH="${IPA_DIR}/CBrainIOS.tipa"

rm -rf "${BUILD_DIR}"
mkdir -p "${IPA_DIR}"

xcodebuild \
  -project "${ROOT_DIR}/CBrainIOS.xcodeproj" \
  -scheme CBrainIOS \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "${DERIVED_DATA}" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  clean build

if [[ ! -d "${APP_PATH}" ]]; then
  echo "App bundle not found: ${APP_PATH}" >&2
  exit 1
fi

if [[ ! -f "${APP_PATH}/Info.plist" ]]; then
  echo "Info.plist not found in app bundle: ${APP_PATH}/Info.plist" >&2
  exit 1
fi

/usr/bin/plutil -lint "${APP_PATH}/Info.plist"
/usr/libexec/PlistBuddy -c "Print CFBundleIdentifier" "${APP_PATH}/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Print CFBundleExecutable" "${APP_PATH}/Info.plist" >/dev/null

WORK_DIR="${BUILD_DIR}/PayloadWork"
mkdir -p "${WORK_DIR}/Payload"
cp -R "${APP_PATH}" "${WORK_DIR}/Payload/"

(
  cd "${WORK_DIR}"
  /usr/bin/ditto -c -k --keepParent Payload "${IPA_PATH}"
)

/usr/bin/unzip -tq "${IPA_PATH}" "Payload/CBrainIOS.app/Info.plist" >/dev/null
cp "${IPA_PATH}" "${TIPA_PATH}"

echo "${IPA_PATH}"
echo "${TIPA_PATH}"
