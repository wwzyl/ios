# CBrain iOS

这是从 Android 端逻辑重新整理出的 iOS 原生 SwiftUI 工程。它不是 APK 转换产物，而是兼容 CBrain 知识库目录格式的 iOS 版本。

## GitHub Actions 构建

1. 把本文件夹里的源码上传到 GitHub 仓库根目录。
2. 打开仓库的 `Actions` 页面。
3. 运行 `Build iOS IPA`。
4. 下载 artifact：`CBrainIOS-installables`。
5. 解压 artifact，里面会有：

```text
CBrainIOS.ipa
CBrainIOS.tipa
```

TrollStore 安装时优先使用 `CBrainIOS.tipa`。不要把源码压缩包、GitHub artifact 外层 zip、或者解压出来的 `Payload` 文件夹拿去安装。

如果 TrollStore 报 `parse error 302` 或 `unable to locate Info.plist inside app bundle`，说明它没有读到标准 IPA 结构。标准结构必须是：

```text
Payload/CBrainIOS.app/Info.plist
```

当前 GitHub Actions 打包脚本会在上传前验证这个路径是否存在，不满足会直接让构建失败。

## 知识库格式

选择的知识库文件夹需要直接包含：

- `graph.json`
- `notes`
- 可选：`modifys` 或 `modifys.json`

iOS 版会把选中的知识库复制到 App 的 Documents 目录：

```text
CBrain Library
```

编辑保存会写入这个 App 内部副本。从 S3 全量下载时，也会写入同一个 App 内部目录。
